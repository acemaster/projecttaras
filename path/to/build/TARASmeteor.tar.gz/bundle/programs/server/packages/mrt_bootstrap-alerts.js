(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;

/* Package-scope variables */
var Alerts;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/mrt_bootstrap-alerts/packages/mrt_bootstrap-alerts.js    //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['mrt:bootstrap-alerts'] = {}, {
  Alerts: Alerts
});

})();
