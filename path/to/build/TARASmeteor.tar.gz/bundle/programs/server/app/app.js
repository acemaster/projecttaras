var require = meteorInstall({"lib":{"collections":{"init.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// lib/collections/init.js                                                                                      //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
function deg2rad(angle) {                                                                                       // 1
  return angle * .017453292519943295;                                                                           // 2
}                                                                                                               //
                                                                                                                //
function getDistance(latitude1, longitude1, latitude2, longitude2) {                                            // 5
  var earth_radius = 6371;                                                                                      // 6
                                                                                                                //
  var dLat = deg2rad(latitude2 - latitude1);                                                                    // 8
  var dLon = deg2rad(longitude2 - longitude1);                                                                  // 9
                                                                                                                //
  var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(deg2rad(latitude1)) * Math.cos(deg2rad(latitude2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
  var c = 2 * Math.asin(Math.sqrt(a));                                                                          // 12
  var d = earth_radius * c;                                                                                     // 13
                                                                                                                //
  return d;                                                                                                     // 15
}                                                                                                               //
                                                                                                                //
AdminConfig = {                                                                                                 // 18
  name: 'TARAS',                                                                                                // 19
  skin: 'black-light',                                                                                          // 20
  collections: {                                                                                                // 21
    Accidents: {},                                                                                              // 22
    Hospitals: {},                                                                                              // 23
    PoliceStation: {},                                                                                          // 24
    AccidentMap: {},                                                                                            // 25
    UserProfile: {},                                                                                            // 26
    UserDevice: {},                                                                                             // 27
    Manufacturer: {}                                                                                            // 28
  }                                                                                                             //
};                                                                                                              //
                                                                                                                //
Schemas = {};                                                                                                   // 32
Accidents = new Mongo.Collection('Accidents');                                                                  // 33
Hospitals = new Mongo.Collection('Hospitals');                                                                  // 34
PoliceStation = new Mongo.Collection('PoliceStation');                                                          // 35
AccidentMap = new Mongo.Collection('Map');                                                                      // 36
UserProfile = new Mongo.Collection('UserProfile');                                                              // 37
UserDevice = new Mongo.Collection('UserDevice');                                                                // 38
Manufacturer = new Mongo.Collection('Manufacturer');                                                            // 39
                                                                                                                //
//=================One Accident data for reference============================                                  //
//{"deaths": 1, "lon": "79.518999", "date": "2008-01-01T00:00:00", "location": "Fatimanagar\nRly.bridge\n", "vehicle": "Truck x  cycle", "lat": "17.982444", "injuries": 0}
//============================================================================                                  //
                                                                                                                //
//===========================Schema Definitions===============================                                  //
//Accidents                                                                                                     //
Schemas.Accidents = new SimpleSchema({                                                                          // 47
  deaths: {                                                                                                     // 48
    type: Number,                                                                                               // 49
    label: 'Deaths',                                                                                            // 50
    min: 0                                                                                                      // 51
  },                                                                                                            //
  longt: {                                                                                                      // 53
    type: String,                                                                                               // 54
    label: 'Longtitude',                                                                                        // 55
    max: 1000                                                                                                   // 56
  },                                                                                                            //
  lat: {                                                                                                        // 58
    type: String,                                                                                               // 59
    label: 'Latitude',                                                                                          // 60
    max: 1000                                                                                                   // 61
  },                                                                                                            //
  date: {                                                                                                       // 63
    type: String,                                                                                               // 64
    label: 'Date',                                                                                              // 65
    max: 1000                                                                                                   // 66
  },                                                                                                            //
  location: {                                                                                                   // 68
    type: String,                                                                                               // 69
    label: 'Location',                                                                                          // 70
    max: 1000                                                                                                   // 71
  },                                                                                                            //
  vehicle: {                                                                                                    // 73
    type: String,                                                                                               // 74
    label: 'Vehicles',                                                                                          // 75
    max: 10000                                                                                                  // 76
  },                                                                                                            //
  injuries: {                                                                                                   // 78
    type: Number,                                                                                               // 79
    label: 'Injuries',                                                                                          // 80
    min: 0                                                                                                      // 81
  }                                                                                                             //
});                                                                                                             //
                                                                                                                //
//Hospitals                                                                                                     //
Schemas.Hospitals = new SimpleSchema({                                                                          // 86
  userId: {                                                                                                     // 87
    type: String,                                                                                               // 88
    label: 'UserId',                                                                                            // 89
    max: 10000,                                                                                                 // 90
    autoform: {                                                                                                 // 91
      options: function () {                                                                                    // 92
        function options() {                                                                                    // 92
          return Meteor.users.find({ roles: 'Hospital' }).map(function (doc) {                                  // 93
            return { label: doc.username, value: doc._id };                                                     // 94
          });                                                                                                   //
        }                                                                                                       //
                                                                                                                //
        return options;                                                                                         //
      }()                                                                                                       //
    }                                                                                                           //
  },                                                                                                            //
  address: {                                                                                                    // 99
    type: String,                                                                                               // 100
    label: 'Address',                                                                                           // 101
    max: 10000                                                                                                  // 102
  },                                                                                                            //
  longt: {                                                                                                      // 104
    type: String,                                                                                               // 105
    label: 'Longtitude',                                                                                        // 106
    max: 1000                                                                                                   // 107
  },                                                                                                            //
  lat: {                                                                                                        // 109
    type: String,                                                                                               // 110
    label: 'Latitude',                                                                                          // 111
    max: 1000                                                                                                   // 112
  }                                                                                                             //
});                                                                                                             //
                                                                                                                //
//PoliceStation                                                                                                 //
Schemas.PoliceStation = new SimpleSchema({                                                                      // 117
  userId: {                                                                                                     // 118
    type: String,                                                                                               // 119
    label: 'UserId',                                                                                            // 120
    max: 10000,                                                                                                 // 121
    autoform: {                                                                                                 // 122
      options: function () {                                                                                    // 123
        function options() {                                                                                    // 123
          return Meteor.users.find({ roles: 'Police' }).map(function (doc) {                                    // 124
            return { label: doc.username, value: doc._id };                                                     // 125
          });                                                                                                   //
        }                                                                                                       //
                                                                                                                //
        return options;                                                                                         //
      }()                                                                                                       //
    }                                                                                                           //
  },                                                                                                            //
  address: {                                                                                                    // 130
    type: String,                                                                                               // 131
    label: 'Address',                                                                                           // 132
    max: 10000                                                                                                  // 133
  },                                                                                                            //
  longt: {                                                                                                      // 135
    type: String,                                                                                               // 136
    label: 'Longtitude',                                                                                        // 137
    max: 1000                                                                                                   // 138
  },                                                                                                            //
  lat: {                                                                                                        // 140
    type: String,                                                                                               // 141
    label: 'Latitude',                                                                                          // 142
    max: 1000                                                                                                   // 143
  }                                                                                                             //
});                                                                                                             //
                                                                                                                //
//AccidentMap                                                                                                   //
//status 0 accident doesnot have hospital                                                                       //
//status 3 accident is in process of getting hospital                                                           //
//status 1 accident got hospital                                                                                //
Schemas.AccidentMap = new SimpleSchema({                                                                        // 151
  UserId: {                                                                                                     // 152
    type: String,                                                                                               // 153
    label: 'User ID',                                                                                           // 154
    max: 10000,                                                                                                 // 155
    autoform: {                                                                                                 // 156
      options: function () {                                                                                    // 157
        function options() {                                                                                    // 157
          return Meteor.users.find({}).map(function (doc) {                                                     // 158
            return { label: doc.username, value: doc._id };                                                     // 159
          });                                                                                                   //
        }                                                                                                       //
                                                                                                                //
        return options;                                                                                         //
      }()                                                                                                       //
    }                                                                                                           //
  },                                                                                                            //
  HospitalId: {                                                                                                 // 164
    type: String,                                                                                               // 165
    label: 'Hospital ID',                                                                                       // 166
    max: 10000,                                                                                                 // 167
    autoform: {                                                                                                 // 168
      options: function () {                                                                                    // 169
        function options() {                                                                                    // 169
          return Hospitals.find().map(function (doc) {                                                          // 170
            return { label: doc.address, value: doc._id };                                                      // 171
          });                                                                                                   //
        }                                                                                                       //
                                                                                                                //
        return options;                                                                                         //
      }()                                                                                                       //
    }                                                                                                           //
  },                                                                                                            //
  AccidentId: {                                                                                                 // 176
    type: String,                                                                                               // 177
    label: 'Accident ID',                                                                                       // 178
    max: 10000,                                                                                                 // 179
    autoform: {                                                                                                 // 180
      options: function () {                                                                                    // 181
        function options() {                                                                                    // 181
          return Accidents.find().map(function (doc) {                                                          // 182
            return { label: doc._id, value: doc._id };                                                          // 183
          });                                                                                                   //
        }                                                                                                       //
                                                                                                                //
        return options;                                                                                         //
      }()                                                                                                       //
    }                                                                                                           //
  },                                                                                                            //
  PoliceId: {                                                                                                   // 188
    type: String,                                                                                               // 189
    label: 'Police ID',                                                                                         // 190
    max: 10000,                                                                                                 // 191
    autoform: {                                                                                                 // 192
      options: function () {                                                                                    // 193
        function options() {                                                                                    // 193
          return PoliceStation.find().map(function (doc) {                                                      // 194
            return { label: doc.address, value: doc._id };                                                      // 195
          });                                                                                                   //
        }                                                                                                       //
                                                                                                                //
        return options;                                                                                         //
      }()                                                                                                       //
    }                                                                                                           //
  },                                                                                                            //
  Status: {                                                                                                     // 200
    type: Number,                                                                                               // 201
    label: 'Status',                                                                                            // 202
    min: 0                                                                                                      // 203
  }                                                                                                             //
});                                                                                                             //
                                                                                                                //
//UserProfile Schema                                                                                            //
Schemas.UserProfile = new SimpleSchema({                                                                        // 208
  UserId: {                                                                                                     // 209
    type: String,                                                                                               // 210
    label: 'User ID',                                                                                           // 211
    max: 10000,                                                                                                 // 212
    autoform: {                                                                                                 // 213
      options: function () {                                                                                    // 214
        function options() {                                                                                    // 214
          return Meteor.users.find({}).map(function (doc) {                                                     // 215
            return { label: doc.username, value: doc._id };                                                     // 216
          });                                                                                                   //
        }                                                                                                       //
                                                                                                                //
        return options;                                                                                         //
      }()                                                                                                       //
    }                                                                                                           //
  },                                                                                                            //
  name: {                                                                                                       // 221
    type: String,                                                                                               // 222
    label: 'Name',                                                                                              // 223
    max: 10000                                                                                                  // 224
  },                                                                                                            //
  mobileNo: {                                                                                                   // 226
    type: String,                                                                                               // 227
    label: 'Mobile No',                                                                                         // 228
    max: 10000                                                                                                  // 229
  },                                                                                                            //
  personalNumbers: {                                                                                            // 231
    type: [String],                                                                                             // 232
    label: 'Personal Numbers',                                                                                  // 233
    max: 20                                                                                                     // 234
  },                                                                                                            //
  // carNo: {                                                                                                   //
  //   type: String,                                                                                            //
  //   label: 'Car No',                                                                                         //
  //   max: 20,                                                                                                 //
  // },                                                                                                         //
  bloodGroup: {                                                                                                 // 241
    type: String,                                                                                               // 242
    label: 'Blood Group',                                                                                       // 243
    max: 20,                                                                                                    // 244
    allowedValues: ['B+', 'A+', 'AB+', 'O+']                                                                    // 245
  },                                                                                                            //
  allergies: {                                                                                                  // 247
    type: String,                                                                                               // 248
    label: 'Allergies',                                                                                         // 249
    max: 100                                                                                                    // 250
  },                                                                                                            //
  height: {                                                                                                     // 252
    type: String,                                                                                               // 253
    label: 'height',                                                                                            // 254
    max: 100                                                                                                    // 255
  },                                                                                                            //
  weight: {                                                                                                     // 257
    type: String,                                                                                               // 258
    label: 'weight',                                                                                            // 259
    max: 100                                                                                                    // 260
  }                                                                                                             //
});                                                                                                             //
                                                                                                                //
Schemas.Manufacturer = new SimpleSchema({                                                                       // 264
  name: {                                                                                                       // 265
    type: String,                                                                                               // 266
    label: 'Manufacturer name',                                                                                 // 267
    max: 10000                                                                                                  // 268
  },                                                                                                            //
  api_token: {                                                                                                  // 270
    type: String,                                                                                               // 271
    label: 'API Token',                                                                                         // 272
    max: 100000                                                                                                 // 273
  },                                                                                                            //
  api_key: {                                                                                                    // 275
    type: String,                                                                                               // 276
    label: 'API Key',                                                                                           // 277
    max: 100000                                                                                                 // 278
  }                                                                                                             //
});                                                                                                             //
                                                                                                                //
Schemas.UserDevice = new SimpleSchema({                                                                         // 282
  UserId: {                                                                                                     // 283
    type: String,                                                                                               // 284
    label: 'User ID',                                                                                           // 285
    max: 10000,                                                                                                 // 286
    autoform: {                                                                                                 // 287
      options: function () {                                                                                    // 288
        function options() {                                                                                    // 288
          return Meteor.users.find({}).map(function (doc) {                                                     // 289
            return { label: doc.username, value: doc._id };                                                     // 290
          });                                                                                                   //
        }                                                                                                       //
                                                                                                                //
        return options;                                                                                         //
      }()                                                                                                       //
    }                                                                                                           //
  },                                                                                                            //
  ManId: {                                                                                                      // 295
    type: String,                                                                                               // 296
    label: 'Manufacturer ID',                                                                                   // 297
    max: 10000,                                                                                                 // 298
    autoform: {                                                                                                 // 299
      options: function () {                                                                                    // 300
        function options() {                                                                                    // 300
          return Manufacturer.find({}).map(function (doc) {                                                     // 301
            return { label: doc.username, value: doc._id };                                                     // 302
          });                                                                                                   //
        }                                                                                                       //
                                                                                                                //
        return options;                                                                                         //
      }()                                                                                                       //
    }                                                                                                           //
  },                                                                                                            //
  name: {                                                                                                       // 307
    type: String,                                                                                               // 308
    label: 'Device Name',                                                                                       // 309
    max: 10000                                                                                                  // 310
  },                                                                                                            //
  deviceID: {                                                                                                   // 312
    type: String,                                                                                               // 313
    label: 'Device ID',                                                                                         // 314
    max: 10000                                                                                                  // 315
  }                                                                                                             //
});                                                                                                             //
                                                                                                                //
//================Schema Attachments==========================================                                  //
Accidents.attachSchema(Schemas.Accidents);                                                                      // 320
Hospitals.attachSchema(Schemas.Hospitals);                                                                      // 321
PoliceStation.attachSchema(Schemas.PoliceStation);                                                              // 322
AccidentMap.attachSchema(Schemas.AccidentMap);                                                                  // 323
UserProfile.attachSchema(Schemas.UserProfile);                                                                  // 324
UserDevice.attachSchema(Schemas.UserDevice);                                                                    // 325
Manufacturer.attachSchema(Schemas.Manufacturer);                                                                // 326
                                                                                                                //
//==================Collection helpers=======================================                                   //
//===================Accident Map helpers====================================                                   //
AccidentMap.helpers({                                                                                           // 331
  getHospital: function () {                                                                                    // 332
    function getHospital() {                                                                                    //
      return Hospitals.findOne({ _id: this.HospitalId });                                                       // 333
    }                                                                                                           //
                                                                                                                //
    return getHospital;                                                                                         //
  }(),                                                                                                          //
  getPoliceStation: function () {                                                                               // 335
    function getPoliceStation() {                                                                               //
      return PoliceStation.findOne({ _id: this.PoliceId });                                                     // 336
    }                                                                                                           //
                                                                                                                //
    return getPoliceStation;                                                                                    //
  }(),                                                                                                          //
  getAccident: function () {                                                                                    // 338
    function getAccident() {                                                                                    //
      return Accidents.findOne({ _id: this.AccidentId });                                                       // 339
    }                                                                                                           //
                                                                                                                //
    return getAccident;                                                                                         //
  }()                                                                                                           //
});                                                                                                             //
                                                                                                                //
//===================Accident Helpers=======================================                                    //
Accidents.helpers({                                                                                             // 344
  getHospitalDistance: function () {                                                                            // 345
    function getHospitalDistance(hosp) {                                                                        //
      var distance = getDistance(this.lat, this.longt, hosp.lat, hosp.longt);                                   // 347
      return distance;                                                                                          // 348
    }                                                                                                           //
                                                                                                                //
    return getHospitalDistance;                                                                                 //
  }(),                                                                                                          //
  getPoliceStationDistance: function () {                                                                       // 350
    function getPoliceStationDistance(police) {                                                                 //
      var distance = getDistance(this.lat, this.longt, police.lat, police.longt);                               // 352
      return distance;                                                                                          // 353
    }                                                                                                           //
                                                                                                                //
    return getPoliceStationDistance;                                                                            //
  }(),                                                                                                          //
  getNearestHospital: function () {                                                                             // 355
    function getNearestHospital() {                                                                             //
      var hospitals = Hospitals.find({});                                                                       // 357
      var distances = [];                                                                                       // 358
      var accident = this;                                                                                      // 359
      hospitals.forEach(function (obj) {                                                                        // 360
        var dist = accident.getHospitalDistance(obj);                                                           // 361
        distances.push([obj._id, dist]);                                                                        // 362
      });                                                                                                       //
      distances.sort(function (a, b) {                                                                          // 364
        return b[1] - a[1];                                                                                     // 364
      });                                                                                                       //
      // console.log(String(distances));                                                                        //
      return distances;                                                                                         // 356
    }                                                                                                           //
                                                                                                                //
    return getNearestHospital;                                                                                  //
  }(),                                                                                                          //
  getNearestPolice: function () {                                                                               // 368
    function getNearestPolice() {                                                                               //
      var allPoliceStations = PoliceStation.find({});                                                           // 370
      var distances = [];                                                                                       // 371
      var accident = this;                                                                                      // 372
      allPoliceStations.forEach(function (obj) {                                                                // 373
        var dist = accident.getPoliceStationDistance(obj);                                                      // 374
        distances.push([obj._id, dist]);                                                                        // 375
      });                                                                                                       //
      distances.sort(function (a, b) {                                                                          // 377
        return b[1] - a[1];                                                                                     // 377
      });                                                                                                       //
      // console.log(String(distances));                                                                        //
      return distances;                                                                                         // 369
    }                                                                                                           //
                                                                                                                //
    return getNearestPolice;                                                                                    //
  }()                                                                                                           //
});                                                                                                             //
                                                                                                                //
//===================Manufacturer Helpers============================                                           //
UserDevice.helpers({                                                                                            // 384
  getManufacturerName: function () {                                                                            // 385
    function getManufacturerName() {                                                                            //
      return Manufacturer.findOne({ _id: this.ManId });                                                         // 387
    }                                                                                                           //
                                                                                                                //
    return getManufacturerName;                                                                                 //
  }()                                                                                                           //
});                                                                                                             //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"routes.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// lib/routes.js                                                                                                //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
//================================Routes===================================                                     //
                                                                                                                //
Router.configure({                                                                                              // 3
	layoutTemplate: 'main'                                                                                         // 4
});                                                                                                             //
                                                                                                                //
Router.route('/', {                                                                                             // 7
	name: 'home',                                                                                                  // 8
	action: function () {                                                                                          // 9
		function action() {                                                                                           // 9
			if (Meteor.isCordova) {                                                                                      // 11
				this.render('login');                                                                                       // 12
			} else {                                                                                                     //
				this.layout('');                                                                                            // 14
				this.render('homepage');                                                                                    // 15
			}                                                                                                            //
		}                                                                                                             //
                                                                                                                //
		return action;                                                                                                //
	}()                                                                                                            //
});                                                                                                             //
                                                                                                                //
Router.route('/uploadjson', {                                                                                   // 20
	name: 'upload',                                                                                                // 21
	template: 'uploadjson'                                                                                         // 22
});                                                                                                             //
                                                                                                                //
Router.route('/map', {                                                                                          // 25
	name: 'map',                                                                                                   // 26
	action: function () {                                                                                          // 27
		function action() {                                                                                           // 27
			if (Meteor.isCordova) {                                                                                      // 29
				this.render('login');                                                                                       // 30
			} else {                                                                                                     //
				this.render('map');                                                                                         // 32
			}                                                                                                            //
		}                                                                                                             //
                                                                                                                //
		return action;                                                                                                //
	}()                                                                                                            //
});                                                                                                             //
                                                                                                                //
Router.route('/adduser', {                                                                                      // 37
	name: 'adduser',                                                                                               // 38
	template: 'adduser'                                                                                            // 39
});                                                                                                             //
                                                                                                                //
Router.route('/logout', function () {                                                                           // 42
	Meteor.logout();                                                                                               // 43
	this.render('map');                                                                                            // 44
});                                                                                                             //
                                                                                                                //
Router.route('/login', {                                                                                        // 47
	name: 'login',                                                                                                 // 48
	template: 'login'                                                                                              // 49
});                                                                                                             //
                                                                                                                //
Router.route('/register', {                                                                                     // 52
	name: 'register',                                                                                              // 53
	template: 'register'                                                                                           // 54
});                                                                                                             //
                                                                                                                //
Router.route('/portal', {                                                                                       // 57
	name: 'portal',                                                                                                // 58
	template: 'portal'                                                                                             // 59
});                                                                                                             //
                                                                                                                //
Router.route('/profile', {                                                                                      // 62
	name: 'profile',                                                                                               // 63
	template: 'profile'                                                                                            // 64
});                                                                                                             //
                                                                                                                //
Router.route('/userdevices', {                                                                                  // 67
	name: 'userdevices',                                                                                           // 68
	template: 'userDevice'                                                                                         // 69
});                                                                                                             //
                                                                                                                //
Router.route('/dummy', {                                                                                        // 72
	name: 'dummy',                                                                                                 // 73
	template: 'dummy'                                                                                              // 74
});                                                                                                             //
                                                                                                                //
// var mustBeSignedIn = function(pause) {                                                                       //
//   console.log("Hello");                                                                                      //
//   if (!(Meteor.user() || Meteor.loggingIn())) {                                                              //
//     Router.go('/login');                                                                                     //
//     pause();                                                                                                 //
//   }                                                                                                          //
// };                                                                                                           //
//                                                                                                              //
// var goToDashboard = function(pause) {                                                                        //
//   console.log("Hello user");                                                                                 //
//   if (Meteor.user()) {                                                                                       //
//     Router.go('/map');                                                                                       //
//     pause();                                                                                                 //
//   }                                                                                                          //
// };                                                                                                           //
//                                                                                                              //
// Router.onBeforeAction(mustBeSignedIn, {except: ['/login']});                                                 //
// Router.onBeforeAction(goToDashboard, {only: ['/login']});                                                    //
                                                                                                                //
Router.route('/reguserprofile', {                                                                               // 98
	name: 'reguserprofile'                                                                                         // 99
});                                                                                                             //
                                                                                                                //
Router.route('/api/insert/accident', function () {                                                              // 102
	this.response.statusCode = 200;                                                                                // 103
	this.response.setHeader("Content-Type", "application/json");                                                   // 104
	this.response.setHeader("Access-Control-Allow-Origin", "*");                                                   // 105
	this.response.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");     // 106
	var lat = this.request.body.lat;                                                                               // 107
	var longt = this.request.body.longt;                                                                           // 108
	var id = this.request.body.userId;                                                                             // 109
	var response = "";                                                                                             // 110
	var address = "";                                                                                              // 111
	console.log(id);                                                                                               // 112
	if (id) {                                                                                                      // 113
		Meteor.call('getaddress', lat, longt, function (error, result) {                                              // 115
			if (error) {                                                                                                 // 116
				response = response + String(error);                                                                        // 118
				console.log(error);                                                                                         // 119
			} else {                                                                                                     //
				address = result.data.results[0].formatted_address;                                                         // 122
				accident = Accidents.insert({                                                                               // 123
					'deaths': 0,                                                                                               // 124
					'longt': longt,                                                                                            // 125
					'lat': lat,                                                                                                // 126
					'date': new Date(),                                                                                        // 127
					'location': address,                                                                                       // 128
					'vehicle': 'Car x Vehicle',                                                                                // 129
					'injuries': 1                                                                                              // 130
				});                                                                                                         //
				if (accident) {                                                                                             // 132
					user = Meteor.users.findOne({ '_id': id });                                                                // 134
					if (user) {                                                                                                // 135
						hospitals = Accidents.findOne({ _id: accident }).getNearestHospital();                                    // 136
						policestations = Accidents.findOne({ _id: accident }).getNearestPolice();                                 // 137
						// console.log(hospitals);                                                                                //
						// console.log(policestations);                                                                           //
						for (var i = 0; i < hospitals.length && i < 5; i++) {                                                     // 135
							AccidentMap.insert({                                                                                     // 142
								'UserId': id,                                                                                           // 143
								'HospitalId': hospitals[i][0],                                                                          // 144
								'PoliceId': policestations[0][0],                                                                       // 145
								'AccidentId': accident,                                                                                 // 146
								'Status': 0                                                                                             // 147
							});                                                                                                      //
						}                                                                                                         //
						//Send sms to all the people related to the user                                                          //
						console.log("Informed police");                                                                           // 135
						response = response + "Accident created and informed";                                                    // 152
					} else response = response + "User not found";                                                             //
				} else response = response + "Accident couldnot be created";                                                //
			}                                                                                                            //
		});                                                                                                           //
	}                                                                                                              //
	this.response.end(response);                                                                                   // 162
}, { where: 'server' });                                                                                        //
                                                                                                                //
Router.route('/saiteja', function () {                                                                          // 166
	this.response.statusCode = 200;                                                                                // 167
	this.response.setHeader("Content-Type", "application/json");                                                   // 168
	this.response.setHeader("Access-Control-Allow-Origin", "*");                                                   // 169
	this.response.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");     // 170
	var response = "Hello";                                                                                        // 171
	this.response.end(response);                                                                                   // 172
}, { where: 'server' });                                                                                        //
                                                                                                                //
Router.route('/api/insert/accidentsms', function () {                                                           // 175
	this.response.statusCode = 200;                                                                                // 176
	this.response.setHeader("Content-Type", "application/json");                                                   // 177
	this.response.setHeader("Access-Control-Allow-Origin", "*");                                                   // 178
	this.response.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");     // 179
	var message = this.request.body.message;                                                                       // 180
	var number = this.request.body.number;                                                                         // 181
	var keyword = this.request.body.keyword;                                                                       // 182
	var latlongt = message.split(",");                                                                             // 183
	var lat = latlongt[0];                                                                                         // 184
	var longt = latlongt[1];                                                                                       // 185
	var id = latlongt[2];                                                                                          // 186
	var deviceId = latlongt[3];                                                                                    // 187
	var response = "";                                                                                             // 188
	var address = "";                                                                                              // 189
	console.log(id);                                                                                               // 190
	if (id) {                                                                                                      // 191
		Meteor.call('getaddress', lat, longt, function (error, result) {                                              // 193
			if (error) {                                                                                                 // 194
				response = response + String(error);                                                                        // 196
				console.log(error);                                                                                         // 197
			} else {                                                                                                     //
				address = result.data.results[0].formatted_address;                                                         // 200
				accident = Accidents.insert({                                                                               // 201
					'deaths': 0,                                                                                               // 202
					'longt': longt,                                                                                            // 203
					'lat': lat,                                                                                                // 204
					'date': new Date(),                                                                                        // 205
					'location': address,                                                                                       // 206
					'vehicle': 'Car x Vehicle',                                                                                // 207
					'injuries': 1                                                                                              // 208
				});                                                                                                         //
				if (accident) {                                                                                             // 210
					user = Meteor.users.findOne({ '_id': id });                                                                // 212
					if (user) {                                                                                                // 213
						hospitals = Accidents.findOne({ _id: accident }).getNearestHospital();                                    // 214
						policestations = Accidents.findOne({ _id: accident }).getNearestPolice();                                 // 215
						// console.log(hospitals);                                                                                //
						// console.log(policestations);                                                                           //
						for (var i = 0; i < hospitals.length && i < 5; i++) {                                                     // 213
							AccidentMap.insert({                                                                                     // 220
								'UserId': id,                                                                                           // 221
								'HospitalId': hospitals[i][0],                                                                          // 222
								'PoliceId': policestations[0][0],                                                                       // 223
								'AccidentId': accident,                                                                                 // 224
								'Status': 0                                                                                             // 225
							});                                                                                                      //
						}                                                                                                         //
						//Send sms to all the people related to the user                                                          //
						console.log("Informed police");                                                                           // 213
						response = response + "Accident created and informed";                                                    // 230
					} else response = response + "User not found";                                                             //
				} else response = response + "Accident couldnot be created";                                                //
			}                                                                                                            //
		});                                                                                                           //
	}                                                                                                              //
	this.response.end(response);                                                                                   // 240
}, { where: 'server' });                                                                                        //
                                                                                                                //
// Router.route('/api/getaccidents', function(){                                                                //
//   this.response.statusCode = 200;                                                                            //
//   this.response.setHeader("Content-Type", "application/json");                                               //
//   this.response.setHeader("Access-Control-Allow-Origin", "*");                                               //
//   this.response.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
//   var lat=this.request.body.lat;                                                                             //
//   var lont=this.request.body.longt;                                                                          //
//   console.log("Lat: "+ lat+" Longt: "+ lont);                                                                //
                                                                                                                //
//   }                                                                                                          //
//   this.response.end(response);                                                                               //
// }, {where: 'server'});                                                                                       //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"init.js":function(require){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// server/init.js                                                                                               //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
Accounts.config({                                                                                               // 1
  forbidClientAccountCreation: true                                                                             // 2
});                                                                                                             //
                                                                                                                //
Meteor.startup(function () {                                                                                    // 10
  // $.getScript('https://maps.googleapis.com/maps/api/js', function(){});                                      //
  console.log("Server init started........");                                                                   // 12
  UploadServer.init({                                                                                           // 13
    tmpDir: process.env.PWD + '/.uploads/tmp',                                                                  // 14
    uploadDir: process.env.PWD + '/.uploads/',                                                                  // 15
    checkCreateDirectories: true,                                                                               // 16
    validateFile: function () {                                                                                 // 17
      function validateFile(file, req) {                                                                        // 17
        // e.g. read file content                                                                               //
        Fiber = Npm.require('fibers');                                                                          // 19
        console.log(file);                                                                                      // 20
        var path = file.path;                                                                                   // 21
        var fs = Npm.require('fs');                                                                             // 22
        var obj = JSON.parse(fs.readFileSync(path, 'utf8'));                                                    // 23
        Fiber(function () {                                                                                     // 24
          for (var i = 0, len = obj.length; i < len; i++) {                                                     // 25
            Accidents.insert({                                                                                  // 27
              deaths: obj[i].deaths,                                                                            // 28
              longt: obj[i].lon,                                                                                // 29
              lat: obj[i].lat,                                                                                  // 30
              date: obj[i].date,                                                                                // 31
              location: obj[i].location,                                                                        // 32
              vehicle: obj[i].vehicle,                                                                          // 33
              injuries: obj[i].injuries                                                                         // 34
            });                                                                                                 //
            console.log(obj[i]);                                                                                // 36
          }                                                                                                     //
        }).run();                                                                                               //
        // console.log(obj);                                                                                    //
        return null;                                                                                            // 17
      }                                                                                                         //
                                                                                                                //
      return validateFile;                                                                                      //
    }()                                                                                                         //
  });                                                                                                           //
                                                                                                                //
  Meteor.methods({                                                                                              // 44
    addnewuser: function () {                                                                                   // 45
      function addnewuser(emailaddress, password, roles, userinfo) {                                            // 45
        var user = Accounts.createUser({                                                                        // 46
          'username': emailaddress,                                                                             // 47
          'email': emailaddress,                                                                                // 48
          'password': password,                                                                                 // 49
          'roles': roles,                                                                                       // 50
          'userinfo': userinfo                                                                                  // 51
        });                                                                                                     //
        return user;                                                                                            // 53
      }                                                                                                         //
                                                                                                                //
      return addnewuser;                                                                                        //
    }(),                                                                                                        //
    getaddress: function () {                                                                                   // 55
      function getaddress(lat, longt) {                                                                         // 55
        this.unblock();                                                                                         // 56
        var url = "http://maps.googleapis.com/maps/api/geocode/json?latlng=" + lat + "," + longt;               // 57
        console.log("Url to call....:" + url);                                                                  // 58
        result = Meteor.http.call("GET", url);                                                                  // 59
        console.log(result);                                                                                    // 60
        return result;                                                                                          // 61
      }                                                                                                         //
                                                                                                                //
      return getaddress;                                                                                        //
    }(),                                                                                                        //
    removeOtherHospitals: function () {                                                                         // 63
      function removeOtherHospitals(MapId, HospitalId, AccidentId) {                                            // 63
        //console.log(AccidentMap.find({AccidentId: AccidentId}).fetch());                                      //
        AccidentMap.update({ AccidentId: AccidentId }, { $set: { Status: 3 } }, function (error) {              // 66
          if (error) {                                                                                          // 67
            console.log(error);                                                                                 // 68
          }                                                                                                     //
        });                                                                                                     //
        var accidents = AccidentMap.find({ 'AccidentId': AccidentId });                                         // 71
        accidents.forEach(function (obj) {                                                                      // 72
          if (obj.HospitalId != HospitalId) AccidentMap.remove(obj._id);                                        // 73
        });                                                                                                     //
        AccidentMap.update(MapId, { $set: { Status: 1 } }, function (error) {                                   // 76
          if (error) {                                                                                          // 77
            console.log(error);                                                                                 // 78
          }                                                                                                     //
        });                                                                                                     //
      }                                                                                                         //
                                                                                                                //
      return removeOtherHospitals;                                                                              //
    }(),                                                                                                        //
    addUserProfile: function () {                                                                               // 82
      function addUserProfile(UserId, name, mobileNo, personalNumbers, bloodGroup, allergies, height, weight) {
        u = UserProfile.insert({                                                                                // 83
          'UserId': UserId,                                                                                     // 84
          'name': name,                                                                                         // 85
          'mobileNo': mobileNo,                                                                                 // 86
          'personalNumbers': personalNumbers,                                                                   // 87
          'bloodGroup': bloodGroup,                                                                             // 88
          'allergies': allergies,                                                                               // 89
          'height': height,                                                                                     // 90
          'weight': weight                                                                                      // 91
        });                                                                                                     //
      }                                                                                                         //
                                                                                                                //
      return addUserProfile;                                                                                    //
    }(),                                                                                                        //
                                                                                                                //
    // 'carNo': carNo,                                                                                          //
    addDevice: function () {                                                                                    // 96
      function addDevice(UserId, name, deviceID, manID) {                                                       // 96
        console.log(manID);                                                                                     // 98
        u = UserDevice.insert({                                                                                 // 99
          'UserId': UserId,                                                                                     // 100
          'ManId': manID,                                                                                       // 101
          'name': name,                                                                                         // 102
          'deviceID': deviceID                                                                                  // 103
                                                                                                                //
        });                                                                                                     //
      }                                                                                                         //
                                                                                                                //
      return addDevice;                                                                                         //
    }(),                                                                                                        //
    updateUserProfile: function () {                                                                            // 107
      function updateUserProfile(UserId, name, mobileNo, personalNumbers, carNo) {                              // 107
        u = UserProfile.update({ 'UserId': UserId }, { $set: {                                                  // 108
            'name': name,                                                                                       // 109
            'mobileNo': mobileNo,                                                                               // 110
            'personalNumbers': personalNumbers                                                                  // 111
          }                                                                                                     //
        });                                                                                                     //
      }                                                                                                         //
                                                                                                                //
      return updateUserProfile;                                                                                 //
    }(),                                                                                                        //
    // 'carNo': carNo,                                                                                          //
    addNormalUser: function () {                                                                                // 119
      function addNormalUser(emailaddress, password) {                                                          // 119
        roles = [];                                                                                             // 121
        roles.push("Normal");                                                                                   // 122
        setProfile = 0;                                                                                         // 123
        userId = Accounts.createUser({                                                                          // 124
          'username': emailaddress,                                                                             // 125
          'email': emailaddress,                                                                                // 126
          'password': password,                                                                                 // 127
          'roles': roles,                                                                                       // 128
          'setProfile': setProfile                                                                              // 129
        });                                                                                                     //
                                                                                                                //
        return userId;                                                                                          // 132
      }                                                                                                         //
                                                                                                                //
      return addNormalUser;                                                                                     //
    }(),                                                                                                        //
    getProfileStatus: function () {                                                                             // 136
      function getProfileStatus(userId) {                                                                       // 136
        user = Meteor.users.findOne({ _id: userId });                                                           // 137
        console.log(user.setProfile);                                                                           // 138
        if (user.setProfile == 0) return true;else return false;                                                // 139
      }                                                                                                         //
                                                                                                                //
      return getProfileStatus;                                                                                  //
    }(),                                                                                                        //
                                                                                                                //
    sendSMS: function () {                                                                                      // 145
      function sendSMS(number, message) {                                                                       // 145
        url = "https://control.msg91.com/api/sendhttp.php?authkey=105176A5azKn6Yin056c344f3&mobiles=+" + number + "&message=" + message + "&sender=131313&route=1&country=91";
        return Meteor.http.call("GET", url);                                                                    // 148
      }                                                                                                         //
                                                                                                                //
      return sendSMS;                                                                                           //
    }()                                                                                                         //
    // getUser: function(UserId) {                                                                              //
    //   user=Meteor.users.findOne({_id: UserId});                                                              //
    //   if(user)                                                                                               //
    //   {                                                                                                      //
    //     // console.log(user.username);                                                                       //
    //     return user.username;                                                                                //
    //   }                                                                                                      //
    //   else                                                                                                   //
    //     return "Not found";                                                                                  //
    // }                                                                                                        //
                                                                                                                //
    // Variables                                                                                                //
                                                                                                                //
  });                                                                                                           // 44
});                                                                                                             //
                                                                                                                //
Accounts.onCreateUser(function (options, user) {                                                                // 173
  user.profile = {};                                                                                            // 174
  // create a empty array to avoid the Exception while invoking method 'adminCheckAdmin'                        //
  user.emails = [];                                                                                             // 173
  if (options.roles) user.roles = options.roles;                                                                // 177
  if (Meteor.users.find({ roles: 'admin' }).count() == 0) {                                                     // 179
    console.log("Creating admin user");                                                                         // 181
    user.roles = ['admin'];                                                                                     // 182
  }                                                                                                             //
  if (options.userinfo) {                                                                                       // 184
    console.log("Creating new hospital or police station");                                                     // 186
    if (options.userinfo.hospitalmember) {                                                                      // 187
      hospital = Hospitals.insert({                                                                             // 189
        'userId': user._id,                                                                                     // 190
        'address': options.userinfo.address,                                                                    // 191
        'longt': options.userinfo.latlongarr[1],                                                                // 192
        'lat': options.userinfo.latlongarr[0]                                                                   // 193
      });                                                                                                       //
      user.orgId = hospital;                                                                                    // 195
    } else if (options.userinfo.policemember) {                                                                 //
      police = PoliceStation.insert({                                                                           // 199
        'userId': user._id,                                                                                     // 200
        'address': options.userinfo.address,                                                                    // 201
        'longt': options.userinfo.latlongarr[1],                                                                // 202
        'lat': options.userinfo.latlongarr[0]                                                                   // 203
      });                                                                                                       //
      user.orgId = police;                                                                                      // 205
    }                                                                                                           //
  }                                                                                                             //
  console.log("Added extra variables..........");                                                               // 208
  return user;                                                                                                  // 209
});                                                                                                             //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"kadira.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// server/kadira.js                                                                                             //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
//For server usage statistics                                                                                   //
Kadira.connect('wXjdYPrWdEnxPTfsQ', 'cd83da7f-3cde-4319-9338-9eb07eb6bd9e');                                    // 2
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// server/publications.js                                                                                       //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
Meteor.publish("getAccidentMap", function () {                                                                  // 1
	if (this.userId) {                                                                                             // 2
		user = Meteor.users.findOne({ _id: this.userId });                                                            // 4
		// console.log(user);                                                                                         //
		if (user.orgId) {                                                                                             // 3
			orgId = user.orgId;                                                                                          // 7
			// console.log(orgId);                                                                                       //
			if (user.roles[0] == 'Hospital') return AccidentMap.find({ 'HospitalId': user.orgId });else return AccidentMap.find({ 'PoliceId': user.orgId });
		}                                                                                                             //
	}                                                                                                              //
});                                                                                                             //
                                                                                                                //
Meteor.publish("getAccidents", function () {                                                                    // 17
	return Accidents.find({});                                                                                     // 18
});                                                                                                             //
                                                                                                                //
Meteor.publish("getHospitals", function () {                                                                    // 21
	return Hospitals.find({});                                                                                     // 22
});                                                                                                             //
                                                                                                                //
Meteor.publish("getPoliceStations", function () {                                                               // 25
	return PoliceStation.find({});                                                                                 // 26
});                                                                                                             //
                                                                                                                //
Meteor.publish("getUsers", function () {                                                                        // 29
	return Meteor.users.find({});                                                                                  // 30
});                                                                                                             //
                                                                                                                //
Meteor.publish("getUserProfiles", function () {                                                                 // 33
	return UserProfile.find({});                                                                                   // 34
});                                                                                                             //
                                                                                                                //
Meteor.publish("userProfile", function () {                                                                     // 37
	userprofile = UserProfile.find({ UserId: this.userId });                                                       // 38
	if (userprofile.count()) return userprofile;else {                                                             // 39
		console.log("Empty user profile list");                                                                       // 42
		return;                                                                                                       // 43
	}                                                                                                              //
});                                                                                                             //
                                                                                                                //
Meteor.publish("userDevice", function () {                                                                      // 47
	userdevice = UserDevice.find({ UserId: this.userId });                                                         // 48
	if (userdevice.count()) return userdevice;else {                                                               // 49
		console.log("Empty user device list");                                                                        // 52
		return;                                                                                                       // 53
	}                                                                                                              //
});                                                                                                             //
                                                                                                                //
Meteor.publish("manufacturers", function () {                                                                   // 57
	return Manufacturer.find({});                                                                                  // 58
});                                                                                                             //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{"extensions":[".js",".json"]});
require("./lib/collections/init.js");
require("./lib/routes.js");
require("./server/init.js");
require("./server/kadira.js");
require("./server/publications.js");
//# sourceMappingURL=app.js.map
